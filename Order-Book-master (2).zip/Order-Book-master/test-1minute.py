import pandas as pd
import numpy as np
from pandas_datareader import data
import matplotlib.pyplot as plt
import requests, json, time, threading, ccxt, datetime
from binance_f import RequestClient
from binance_f.model import *
from binance_f.constant.test import *
from binance_f.base.printobject import *
from github import Github
from github import InputGitTreeElement

request_client = RequestClient(api_key='V3WwgKbt706rFS504of3FewiISFnN0qxvH8K5XFFcVKQ3wkpteyuIS5kDLVZtpf7', secret_key='9zPVDjKxn9XeMjkR809iVLsZAzU3ubMlnXfOQluoY5PAM1B3xSl9jTAjESajhpys')
result = request_client.get_candlestick_data(symbol="BTCUSDT", interval=CandlestickInterval.MIN1, startTime=None, endTime=None, limit=40)
commondf = 0
finaldf = 0
ls = []
initial = []
final = []
fprofit = []
stime = []

def get_candles():
    global result
    result = request_client.get_candlestick_data(symbol="BTCUSDT", interval=CandlestickInterval.HOUR2, startTime=None, endTime=None, limit=40)

def transforming_klines(anykl):
    time = []
    op = []
    high = []
    low = []
    cl = []
    i = 0
    y = 0
    length = len(anykl) - 1
    while i < length:
        time.append(str(datetime.datetime.fromtimestamp(anykl[i][0]/1000)))
        op.append(round(float(anykl[i][1]),2))
        high.append(round(float(anykl[i][2]),2))
        low.append(round(float(anykl[i][3]),2))
        cl.append(round(float(anykl[i][4]),2))
        i += 1
    d = {"Date Time":pd.Series(time), "Open price":pd.Series(op), "High price":pd.Series(high), "Low price":pd.Series(low), "Close price":pd.Series(cl)}
    global commondf
    commondf = pd.DataFrame(d)
    commondf['L14'] = commondf['Low price'].rolling(window=14).min()
    commondf['H14'] = commondf['High price'].rolling(window=14).max()
    commondf['%K'] = 100*((commondf['Close price'] - commondf['L14']) / (commondf['H14'] - commondf['L14']) )
    commondf['%D'] = commondf['%K'].rolling(window=3).mean()
    commondf['Delta1'] = commondf['%D'] - commondf['%K']

def put_massive():
    global commondf
    delta1 = []
    delta2 = []
    signal = []
    t = []
    cl = []
    length = len(commondf)
    i = 13
    a = 12
    while i < length:
        if commondf.iloc[i]['%K'] >= commondf.iloc[i]['%D']:
            if commondf.iloc[a]['%K'] < commondf.iloc[a]['%D']:
                t.append(commondf.iloc[i]['Date Time'])
                cl.append(round(float(commondf.iloc[i]['Close price']),2))
                delta1.append(round(float(commondf.iloc[i]['Delta1']),2))
                if len(delta2) > 0:
                    delta2.append(round(float(abs(delta1[len(delta1)-2] - delta1[len(delta1)-1])),2))
                else:
                    delta2.append('-')
                if float(abs(delta1[len(delta1)-2] - delta1[len(delta1)-1])) >= 16:
                    signal.append('Buy')
                else:
                    signal.append('-')
        elif commondf.iloc[i]['%K'] <= commondf.iloc[i]['%D']:
            if commondf.iloc[a]['%K'] > commondf.iloc[a]['%D']:
                t.append(commondf.iloc[i]['Date Time'])
                cl.append(round(float(commondf.iloc[i]['Close price']),2))
                delta1.append(round(float(commondf.iloc[i]['Delta1']),2))
                if len(delta2) > 0:
                    delta2.append(round(float(abs(delta1[len(delta1)-2] - delta1[len(delta1)-1])),2))
                else:
                    delta2.append('-')
                if float(abs(delta1[len(delta1)-2] - delta1[len(delta1)-1])) >= 16:
                    signal.append('Sell')
                else:
                    signal.append('-')
        i += 1
        a += 1
    dn = {"Time":pd.Series(t), "Close":pd.Series(cl), "Delta1":pd.Series(delta1), "Delta2":pd.Series(delta2), "Signal":pd.Series(signal)}
    global finaldf
    finaldf = pd.DataFrame(dn)

def if_signal():
    global finaldf, ls, initial, final, fprofit, stime
    if len(initial) == len(final):
        i = len(finaldf) - 1
        if finaldf.iloc[i]['Signal'] == 'Buy':
            stime.append(finaldf.iloc[i]['Time'])
            ls.append('Long')
            initial.append(finaldf.iloc[i]['Close'])
            #print('New BUY signal! Close: ' + str(finaldf.iloc[i]['Close']) + ' Time: ' + finaldf.iloc[i]['Time'])
        elif finaldf.iloc[i]['Signal'] == 'Sell':
            stime.append(finaldf.iloc[i]['Time'])
            ls.append('Short')
            initial.append(finaldf.iloc[i]['Close'])
            #print('New SELL signal! Close: ' + str(finaldf.iloc[i]['Close']) + ' Time: ' + finaldf.iloc[i]['Time'])
        else:
            pass
    else:
        e = len(stime) - 1
        i = len(finaldf) - 1
        if stime[e] == finaldf.iloc[i]['Time']:
            pass
        else:
            final.append(finaldf.iloc[i]['Close'])
            if finaldf.iloc[i-1]['Signal'] == 'Buy':
                prof = ((final[e] - initial[e]) / initial[e] - 0.001) * 1000
                #print('BUY signal closed! Close: ' + str(final[e]) + ' Profit: ' + str(prof))
            elif finaldf.iloc[i-1]['Signal'] == 'Sell':
                prof = ((initial[e] - final[e]) / initial[e] - 0.001) * 1000
                #print('SELL signal closed! Close: ' + str(final[e]) + ' Profit: ' + str(prof))
            fprofit.append(str(prof))
            acc = open("accounting.txt", "a")
            acc.write(str(stime[e]))
            acc.write(" ")
            acc.write(str(ls[e]))
            acc.write(" ")
            acc.write(str(initial[e]))
            acc.write(" ")
            acc.write(str(final[e]))
            acc.write(" ")
            acc.write(str(fprofit[e]))
            acc.write(";\n")
            acc.close()
            print('Deal made! :) Now we gonna fucking hoes!')
            #Push to GitHub
            user = "Stuffman"
            password = "Boryan1999"
            g = Github(user,password)
            repo = g.get_user().get_repo('Order-Book')
            file_list = ['accounting.txt']
            file_names = ['accounting.txt']
            commit_message = 'New deal'
            master_ref = repo.get_git_ref('heads/master')
            master_sha = master_ref.object.sha
            base_tree = repo.get_git_tree(master_sha)
            element_list = list()
            for i, entry in enumerate(file_list):
                with open(entry) as input_file:
                    data = input_file.read()
                    element = InputGitTreeElement(file_names[i], '100644', 'blob', data)
                    element_list.append(element)
            tree = repo.create_git_tree(element_list, base_tree)
            parent = repo.get_git_commit(master_sha)
            commit = repo.create_git_commit(commit_message, tree, [parent])
            master_ref.edit(commit.sha)

def doit():   
    get_candles()
    transforming_klines(result)
    put_massive()
    if_signal()
    threading.Timer(1, doit).start()
 
doit()
#input('Press ENTER to exit')
