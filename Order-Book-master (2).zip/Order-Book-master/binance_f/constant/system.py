
class WebSocketDefine:
    Uri = "wss://fstream.binance.com/ws"

class RestApiDefine:
    Url = "https://fapi.binance.com"





